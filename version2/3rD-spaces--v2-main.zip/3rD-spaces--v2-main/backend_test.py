import requests
import sys
import json
from datetime import datetime

class ThirdSpacesAPITester:
    def __init__(self, base_url="https://4aae33b8-c4d7-447f-a944-2476f8405db3.preview.emergentagent.com"):
        self.base_url = base_url
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None, params=None):
        """Run a single API test"""
        url = f"{self.base_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, params=params)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    print(f"   Response: {json.dumps(response_data, indent=2)[:200]}...")
                    return True, response_data
                except:
                    return True, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                print(f"   Response: {response.text[:200]}...")
                return False, {}

        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_root_endpoint(self):
        """Test the root API endpoint"""
        return self.run_test("Root API Endpoint", "GET", "api/", 200)

    def test_create_content(self, title, text):
        """Test creating content with price extraction"""
        data = {"title": title, "text": text}
        success, response = self.run_test("Create Content", "POST", "api/content", 200, data=data)
        if success and 'id' in response:
            print(f"   Created content ID: {response['id']}")
            print(f"   Extracted prices: {response.get('price_mentions', [])}")
            return response['id'], response.get('price_mentions', [])
        return None, []

    def test_get_all_content(self):
        """Test getting all content"""
        success, response = self.run_test("Get All Content", "GET", "api/content", 200)
        if success and isinstance(response, list):
            print(f"   Found {len(response)} content items")
            return response
        return []

    def test_price_filtering(self, min_price=None, max_price=None):
        """Test price filtering functionality"""
        params = {}
        if min_price is not None:
            params['min_price'] = min_price
        if max_price is not None:
            params['max_price'] = max_price
        
        filter_desc = f"min_price={min_price}, max_price={max_price}"
        success, response = self.run_test(f"Price Filtering ({filter_desc})", "GET", "api/content", 200, params=params)
        
        if success and isinstance(response, list):
            print(f"   Filtered results: {len(response)} items")
            for item in response[:2]:  # Show first 2 items
                print(f"   - {item['title']}: prices {item['price_mentions']}")
            return response
        return []

    def test_status_endpoints(self):
        """Test status check endpoints"""
        # Create status check
        data = {"client_name": f"test_client_{datetime.now().strftime('%H%M%S')}"}
        success, response = self.run_test("Create Status Check", "POST", "api/status", 200, data=data)
        
        if success:
            # Get status checks
            self.run_test("Get Status Checks", "GET", "api/status", 200)

    def test_price_extraction_patterns(self):
        """Test various price extraction patterns"""
        test_cases = [
            ("Dollar Sign Format", "This item costs $50 and is worth it", [50.0]),
            ("Multiple Prices", "Coffee costs $4.50, pastries are $6 each", [4.5, 6.0]),
            ("Priced At Format", "This laptop is priced at $1200", [1200.0]),
            ("USD Format", "The service costs 25 USD", [25.0]),
            ("Dollars Word", "I paid 100 dollars for this", [100.0]),
            ("Comma Separated", "The car costs $15,000", [15000.0])
        ]
        
        for title, text, expected_prices in test_cases:
            content_id, extracted_prices = self.test_create_content(title, text)
            if content_id:
                # Check if extracted prices match expected (allowing for floating point precision)
                expected_set = set(expected_prices)
                extracted_set = set(extracted_prices)
                if expected_set == extracted_set:
                    print(f"   ✅ Price extraction correct for: {title}")
                else:
                    print(f"   ❌ Price extraction mismatch for: {title}")
                    print(f"      Expected: {expected_prices}, Got: {extracted_prices}")

def main():
    print("🚀 Starting 3rDspaces API Testing...")
    print("=" * 60)
    
    tester = ThirdSpacesAPITester()
    
    # Test basic endpoints
    print("\n📡 Testing Basic Endpoints")
    print("-" * 30)
    tester.test_root_endpoint()
    tester.test_status_endpoints()
    
    # Test content functionality
    print("\n📝 Testing Content Functionality")
    print("-" * 30)
    
    # Get existing content first
    existing_content = tester.test_get_all_content()
    
    # Test price extraction with various formats
    print("\n🔍 Testing Price Extraction Patterns")
    print("-" * 30)
    tester.test_price_extraction_patterns()
    
    # Test price filtering
    print("\n🎯 Testing Price Filtering")
    print("-" * 30)
    tester.test_price_filtering(min_price=0, max_price=100)
    tester.test_price_filtering(min_price=100, max_price=500)
    tester.test_price_filtering(min_price=1000, max_price=2000)
    tester.test_price_filtering(min_price=50)  # Only min price
    tester.test_price_filtering(max_price=1000)  # Only max price
    
    # Test edge cases
    print("\n⚠️  Testing Edge Cases")
    print("-" * 30)
    tester.test_price_filtering(min_price=5000, max_price=10000)  # Should return empty
    
    # Print final results
    print("\n" + "=" * 60)
    print(f"📊 Final Results: {tester.tests_passed}/{tester.tests_run} tests passed")
    
    if tester.tests_passed == tester.tests_run:
        print("🎉 All tests passed!")
        return 0
    else:
        print("❌ Some tests failed!")
        return 1

if __name__ == "__main__":
    sys.exit(main())