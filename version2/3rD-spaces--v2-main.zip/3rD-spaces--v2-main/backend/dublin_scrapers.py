"""
Dublin Cultural Website Scrapers
Scrapes content from major Dublin cultural venues and websites
"""
import aiohttp
import asyncio
from bs4 import BeautifulSoup
from typing import List, Dict, Optional
import re
from datetime import datetime, timedelta
import logging
from urllib.parse import urljoin, urlparse

logger = logging.getLogger(__name__)

class DublinCulturalScraper:
    def __init__(self):
        self.session = None
        self.scraped_urls = set()
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30),
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()

    def extract_price_mentions(self, text: str) -> List[float]:
        """Extract price mentions from text using enhanced regex patterns"""
        price_patterns = [
            r'€\s*([0-9,]+\.?[0-9]*)',  # €50, €1,200.99 (Euro format)
            r'\$\s*([0-9,]+\.?[0-9]*)',  # $50, $1,200.99
            r'costs?\s*€?\$?\s*([0-9,]+\.?[0-9]*)',  # costs €25, cost 30
            r'priced?\s*at\s*€?\$?\s*([0-9,]+\.?[0-9]*)',  # priced at €100
            r'([0-9,]+\.?[0-9]*)\s*euro?s?',  # 50 euros, 25.99 euro
            r'([0-9,]+\.?[0-9]*)\s*dollars?',  # 50 dollars
            r'tickets?\s*€?\$?\s*([0-9,]+\.?[0-9]*)',  # tickets €20
            r'admission\s*€?\$?\s*([0-9,]+\.?[0-9]*)',  # admission €15
            r'from\s*€?\$?\s*([0-9,]+\.?[0-9]*)',  # from €30
        ]
        
        prices = []
        for pattern in price_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                price_str = match.group(1).replace(',', '')
                try:
                    price = float(price_str)
                    if 0 < price < 10000:  # Reasonable price range
                        prices.append(price)
                except ValueError:
                    continue
        
        return list(set(prices))  # Remove duplicates

    async def scrape_generic_content(self, url: str, site_name: str) -> List[Dict]:
        """Generic scraper for cultural websites"""
        try:
            if url in self.scraped_urls:
                return []
            
            async with self.session.get(url) as response:
                if response.status != 200:
                    logger.warning(f"Failed to scrape {url}: {response.status}")
                    return []
                
                html = await response.text()
                soup = BeautifulSoup(html, 'html.parser')
                
                # Remove script and style elements
                for script in soup(["script", "style"]):
                    script.decompose()
                
                content_items = []
                
                # Try to find articles, events, or content blocks
                content_selectors = [
                    'article', '.event', '.post', '.content', '.article',
                    '.event-item', '.news-item', '[class*="event"]',
                    '[class*="article"]', '[class*="post"]'
                ]
                
                for selector in content_selectors:
                    elements = soup.select(selector)
                    if elements:
                        for element in elements[:10]:  # Limit to 10 items per page
                            item = await self.extract_content_item(element, url, site_name)
                            if item:
                                content_items.append(item)
                        break
                
                # If no specific content found, try to extract from headings and paragraphs
                if not content_items:
                    headings = soup.find_all(['h1', 'h2', 'h3'], limit=5)
                    for heading in headings:
                        item = await self.extract_from_heading(heading, url, site_name)
                        if item:
                            content_items.append(item)
                
                self.scraped_urls.add(url)
                logger.info(f"Scraped {len(content_items)} items from {site_name}")
                return content_items
                
        except Exception as e:
            logger.error(f"Error scraping {url}: {str(e)}")
            return []

    async def extract_content_item(self, element, base_url: str, site_name: str) -> Optional[Dict]:
        """Extract content from a single element"""
        try:
            # Extract title
            title_elem = element.find(['h1', 'h2', 'h3', 'h4', '.title', '[class*="title"]'])
            title = title_elem.get_text(strip=True) if title_elem else "Untitled"
            
            # Extract text content
            text = element.get_text(separator=' ', strip=True)
            
            # Clean up text
            text = re.sub(r'\s+', ' ', text)
            text = text[:1000]  # Limit text length
            
            # Extract link
            link_elem = element.find('a', href=True)
            link = urljoin(base_url, link_elem['href']) if link_elem else base_url
            
            if len(title) > 3 and len(text) > 20:  # Basic content validation
                price_mentions = self.extract_price_mentions(text)
                
                return {
                    'title': title,
                    'text': text,
                    'source_url': link,
                    'source_site': site_name,
                    'category': self.categorize_content(title, text),
                    'location': 'Dublin, Ireland',
                    'price_mentions': price_mentions,
                    'scraped_at': datetime.utcnow(),
                    'content_type': 'scraped'
                }
        except Exception as e:
            logger.error(f"Error extracting content item: {str(e)}")
        
        return None

    async def extract_from_heading(self, heading, base_url: str, site_name: str) -> Optional[Dict]:
        """Extract content starting from a heading"""
        try:
            title = heading.get_text(strip=True)
            
            # Get following content
            text_parts = [title]
            current = heading.next_sibling
            
            for _ in range(3):  # Get next 3 elements
                if current:
                    if hasattr(current, 'get_text'):
                        text_parts.append(current.get_text(strip=True))
                    current = current.next_sibling
            
            text = ' '.join(text_parts)
            text = re.sub(r'\s+', ' ', text)
            
            if len(title) > 3 and len(text) > 30:
                price_mentions = self.extract_price_mentions(text)
                
                return {
                    'title': title,
                    'text': text[:800],
                    'source_url': base_url,
                    'source_site': site_name,
                    'category': self.categorize_content(title, text),
                    'location': 'Dublin, Ireland',
                    'price_mentions': price_mentions,
                    'scraped_at': datetime.utcnow(),
                    'content_type': 'scraped'
                }
        except Exception as e:
            logger.error(f"Error extracting from heading: {str(e)}")
        
        return None

    def categorize_content(self, title: str, text: str) -> str:
        """Categorize content based on keywords"""
        content = (title + ' ' + text).lower()
        
        categories = {
            'events': ['event', 'show', 'concert', 'performance', 'exhibition', 'festival', 'workshop'],
            'food': ['food', 'restaurant', 'cafe', 'dining', 'menu', 'taste', 'eat', 'drink'],
            'arts': ['art', 'gallery', 'museum', 'painting', 'sculpture', 'artist', 'exhibition'],
            'music': ['music', 'concert', 'band', 'singer', 'album', 'song', 'musician'],
            'theatre': ['theatre', 'theater', 'play', 'drama', 'actor', 'stage', 'performance'],
            'nightlife': ['bar', 'pub', 'club', 'nightlife', 'cocktail', 'beer', 'wine'],
            'culture': ['culture', 'cultural', 'heritage', 'history', 'tradition', 'irish']
        }
        
        for category, keywords in categories.items():
            if any(keyword in content for keyword in keywords):
                return category
        
        return 'general'

    async def scrape_dublin_cultural_sites(self) -> List[Dict]:
        """Scrape content from all Dublin cultural websites"""
        dublin_sites = {
            'Lovin Dublin': ['https://lovin.ie/dublin'],
            'Alternative Dublin': ['https://www.alternativedublincity.com/'],
            'Char Food Guide': ['https://charfoodguide.com/category/dublins-food-and-drink-culture-explored/'],
            'Totally Dublin': ['https://www.totallydublin.ie/'],
            'District Magazine': ['https://districtmagazine.ie/'],
            'Bord Gáis Energy Theatre': ['https://www.bordgaisenergytheatre.ie/'],
            '3Olympia': ['https://www.3olympia.ie/'],
            'The Academy': ['https://www.theacademydublin.com/'],
            'Whelans': ['https://www.whelanslive.com/events/'],
            'IMMA': ['https://imma.ie/'],
            'National Gallery': ['https://www.nationalgallery.ie/'],
            'NCH': ['https://www.nch.ie/'],
            'Hugh Lane Gallery': ['https://hughlane.ie/whats-on/'],
            'RHA Gallery': ['https://rhagallery.ie/whats-on/'],
            'Irish National Opera': ['https://www.irishnationalopera.ie/whats-on/'],
            'Gaiety Theatre': ['https://www.gaietytheatre.ie/events/'],
            'Fringe Festival': ['https://www.fringefest.com/festival/whats-on'],
            'Chester Beatty': ['https://chesterbeatty.ie/exhibitions/'],
        }
        
        all_content = []
        
        for site_name, urls in dublin_sites.items():
            for url in urls:
                try:
                    content = await self.scrape_generic_content(url, site_name)
                    all_content.extend(content)
                    await asyncio.sleep(1)  # Be respectful to servers
                except Exception as e:
                    logger.error(f"Failed to scrape {site_name}: {str(e)}")
                    continue
        
        logger.info(f"Total scraped content items: {len(all_content)}")
        return all_content


async def run_dublin_scraper() -> List[Dict]:
    """Run the Dublin cultural scraper"""
    async with DublinCulturalScraper() as scraper:
        return await scraper.scrape_dublin_cultural_sites()


if __name__ == "__main__":
    # Test the scraper
    import asyncio
    
    async def test():
        content = await run_dublin_scraper()
        print(f"Scraped {len(content)} items")
        for item in content[:3]:
            print(f"Title: {item['title']}")
            print(f"Text: {item['text'][:100]}...")
            print(f"Category: {item['category']}")
            print(f"Prices: {item['price_mentions']}")
            print("---")
    
    asyncio.run(test())