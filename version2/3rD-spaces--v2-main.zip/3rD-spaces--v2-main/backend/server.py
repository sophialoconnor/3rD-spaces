from fastapi import FastAPI, APIRouter, Query, BackgroundTasks
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime
import re
from dublin_scrapers import run_dublin_scraper
import asyncio

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI(title="3rDspaces Dublin Cultural Hub", description="Discover Dublin's cultural scene with price-aware filtering")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Define Models
class StatusCheck(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class StatusCheckCreate(BaseModel):
    client_name: str
    
class Content(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    text: str
    price_mentions: List[float] = Field(default_factory=list)
    source_url: Optional[str] = None
    source_site: Optional[str] = None
    category: Optional[str] = "general"
    location: Optional[str] = "Dublin, Ireland"
    content_type: str = "manual"  # manual or scraped
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class ContentCreate(BaseModel):
    title: str
    text: str
    source_url: Optional[str] = None
    category: Optional[str] = "general"

class SearchQuery(BaseModel):
    query: str
    category: Optional[str] = None
    min_price: Optional[float] = None
    max_price: Optional[float] = None


def extract_price_mentions(text: str) -> List[float]:
    """Extract price mentions from text using enhanced regex patterns for Dublin context"""
    price_patterns = [
        r'€\s*([0-9,]+\.?[0-9]*)',  # €50, €1,200.99 (Euro format - primary for Dublin)
        r'\$\s*([0-9,]+\.?[0-9]*)',  # $50, $1,200.99
        r'costs?\s*€?\$?\s*([0-9,]+\.?[0-9]*)',  # costs €25, cost 30
        r'priced?\s*at\s*€?\$?\s*([0-9,]+\.?[0-9]*)',  # priced at €100, price at 50
        r'([0-9,]+\.?[0-9]*)\s*euro?s?',  # 50 euros, 25.99 euro
        r'([0-9,]+\.?[0-9]*)\s*dollars?',  # 50 dollars, 25.99 dollar
        r'tickets?\s*€?\$?\s*([0-9,]+\.?[0-9]*)',  # tickets €20
        r'admission\s*€?\$?\s*([0-9,]+\.?[0-9]*)',  # admission €15
        r'from\s*€?\$?\s*([0-9,]+\.?[0-9]*)',  # from €30
        r'USD\s*([0-9,]+\.?[0-9]*)',  # USD 50
        r'([0-9,]+\.?[0-9]*)\s*USD',  # 50 USD
    ]
    
    prices = []
    for pattern in price_patterns:
        matches = re.finditer(pattern, text, re.IGNORECASE)
        for match in matches:
            price_str = match.group(1).replace(',', '')
            try:
                price = float(price_str)
                if 0 < price < 10000:  # Reasonable price range for Dublin events/food
                    prices.append(price)
            except ValueError:
                continue
    
    return list(set(prices))  # Remove duplicates


# Add your routes to the router instead of directly to app
@api_router.get("/")
async def root():
    return {"message": "Welcome to 3rDspaces Dublin Cultural Hub API"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.dict()
    status_obj = StatusCheck(**status_dict)
    _ = await db.status_checks.insert_one(status_obj.dict())
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    status_checks = await db.status_checks.find().to_list(1000)
    return [StatusCheck(**status_check) for status_check in status_checks]

@api_router.post("/content", response_model=Content)
async def create_content(input: ContentCreate):
    content_dict = input.dict()
    price_mentions = extract_price_mentions(content_dict['text'])
    content_obj = Content(**content_dict, price_mentions=price_mentions, content_type="manual")
    _ = await db.content.insert_one(content_obj.dict())
    return content_obj

@api_router.get("/content", response_model=List[Content])
async def get_content(
    min_price: Optional[float] = Query(None, description="Minimum price filter"),
    max_price: Optional[float] = Query(None, description="Maximum price filter"),
    category: Optional[str] = Query(None, description="Category filter"),
    content_type: Optional[str] = Query(None, description="Content type filter (manual/scraped)")
):
    query = {}
    
    # Build price filter query
    if min_price is not None or max_price is not None:
        price_filter = {}
        if min_price is not None:
            price_filter["$gte"] = min_price
        if max_price is not None:
            price_filter["$lte"] = max_price
        
        # Match documents where at least one price mention falls within the range
        query["price_mentions"] = {"$elemMatch": price_filter}
    
    # Category filter
    if category:
        query["category"] = category
    
    # Content type filter
    if content_type:
        query["content_type"] = content_type
    
    content_list = await db.content.find(query).sort("timestamp", -1).to_list(1000)
    return [Content(**content) for content in content_list]

@api_router.post("/search")
async def search_content(search_query: SearchQuery):
    """Enhanced search functionality with text matching"""
    query = {}
    
    # Text search using MongoDB text search or regex
    if search_query.query.strip():
        # Create text search query
        search_terms = search_query.query.strip().split()
        regex_patterns = [{"$regex": term, "$options": "i"} for term in search_terms]
        
        query["$or"] = [
            {"title": {"$in": regex_patterns}},
            {"text": {"$in": regex_patterns}},
            {"category": {"$regex": search_query.query, "$options": "i"}},
            {"source_site": {"$regex": search_query.query, "$options": "i"}}
        ]
    
    # Price filter
    if search_query.min_price is not None or search_query.max_price is not None:
        price_filter = {}
        if search_query.min_price is not None:
            price_filter["$gte"] = search_query.min_price
        if search_query.max_price is not None:
            price_filter["$lte"] = search_query.max_price
        
        query["price_mentions"] = {"$elemMatch": price_filter}
    
    # Category filter
    if search_query.category:
        query["category"] = search_query.category
    
    try:
        content_list = await db.content.find(query).sort("timestamp", -1).to_list(100)
        results = [Content(**content) for content in content_list]
        
        return {
            "query": search_query.query,
            "total_results": len(results),
            "results": results
        }
    except Exception as e:
        logging.error(f"Search error: {str(e)}")
        return {"query": search_query.query, "total_results": 0, "results": []}

@api_router.get("/categories")
async def get_categories():
    """Get available content categories"""
    categories = await db.content.distinct("category")
    return {"categories": sorted(categories)}

@api_router.post("/scrape-dublin-content")
async def trigger_dublin_scraping(background_tasks: BackgroundTasks):
    """Trigger scraping of Dublin cultural content"""
    background_tasks.add_task(scrape_and_store_dublin_content)
    return {"message": "Dublin content scraping started in background"}

async def scrape_and_store_dublin_content():
    """Background task to scrape and store Dublin cultural content"""
    try:
        logger.info("Starting Dublin cultural content scraping...")
        scraped_content = await run_dublin_scraper()
        
        # Store scraped content in database
        stored_count = 0
        for item in scraped_content:
            # Check if content already exists (avoid duplicates)
            existing = await db.content.find_one({
                "title": item["title"],
                "source_site": item["source_site"]
            })
            
            if not existing:
                # Create Content object
                content_obj = Content(
                    title=item["title"],
                    text=item["text"],
                    price_mentions=item["price_mentions"],
                    source_url=item["source_url"],
                    source_site=item["source_site"],
                    category=item["category"],
                    location=item["location"],
                    content_type="scraped"
                )
                
                await db.content.insert_one(content_obj.dict())
                stored_count += 1
        
        logger.info(f"Stored {stored_count} new Dublin cultural content items")
        
    except Exception as e:
        logger.error(f"Error in Dublin content scraping: {str(e)}")

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()

# Initialize with sample data
@app.on_event("startup")
async def startup_event():
    """Add sample content data on startup and trigger initial scraping"""
    # Check if content collection is empty
    existing_content = await db.content.find_one()
    if not existing_content:
        # Add sample Dublin-focused content
        sample_content = [
            {
                "title": "Dublin Food Festival 2025",
                "text": "The Dublin Food Festival returns with amazing local restaurants. Tickets cost €15 for early bird, €25 at the door. Sample the best of Dublin's culinary scene!",
                "price_mentions": [15.0, 25.0],
                "category": "food",
                "location": "Dublin, Ireland",
                "content_type": "manual",
                "timestamp": datetime.utcnow(),
                "id": str(uuid.uuid4())
            },
            {
                "title": "National Gallery Exhibition",
                "text": "New contemporary Irish art exhibition now open. Admission is €12 for adults, €8 for students. Free entry on Fridays after 5pm.",
                "price_mentions": [12.0, 8.0],
                "category": "arts",
                "location": "Dublin, Ireland",
                "content_type": "manual",
                "timestamp": datetime.utcnow(),
                "id": str(uuid.uuid4())
            },
            {
                "title": "Temple Bar Music Session",
                "text": "Traditional Irish music sessions every Wednesday at O'Donoghue's. Cover charge €5, pints start from €6.50. Authentic Dublin pub experience!",
                "price_mentions": [5.0, 6.5],
                "category": "music",
                "location": "Dublin, Ireland",
                "content_type": "manual",
                "timestamp": datetime.utcnov(),
                "id": str(uuid.uuid4())
            },
            {
                "title": "Guinness Storehouse Tour",
                "text": "Experience Dublin's most famous brewery. Adult tickets €26, student tickets €20. Includes complimentary pint with panoramic city views.",
                "price_mentions": [26.0, 20.0],
                "category": "culture",
                "location": "Dublin, Ireland",
                "content_type": "manual",
                "timestamp": datetime.utcnow(),
                "id": str(uuid.uuid4())
            },
            {
                "title": "Bord Gáis Energy Theatre Show",
                "text": "Hamilton musical coming to Dublin! Tickets from €35 to €125. Book early for best seats. Running March-May 2025.",
                "price_mentions": [35.0, 125.0],
                "category": "theatre",
                "location": "Dublin, Ireland",
                "content_type": "manual",
                "timestamp": datetime.utcnow(),
                "id": str(uuid.uuid4())
            }
        ]
        
        await db.content.insert_many(sample_content)
        logger.info("Sample Dublin cultural content initialized")
    
    # Trigger initial Dublin content scraping in background
    asyncio.create_task(scrape_and_store_dublin_content())