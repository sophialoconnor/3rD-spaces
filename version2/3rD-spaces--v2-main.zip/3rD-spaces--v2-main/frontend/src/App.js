import React, { useState, useEffect } from "react";
import "./App.css";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import axios from "axios";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Homepage Component
const Home = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  
  const images = [
    "https://images.unsplash.com/photo-1715345312087-9460c9f5ea0d?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2NDF8MHwxfHNlYXJjaHwxfHxlbXB0eSUyMGZpZWxkfGVufDB8fHx8MTc1MzU0MDY2Mnww&ixlib=rb-4.1.0&q=85",
    "https://images.unsplash.com/photo-1621975927256-0eee0ff304e4?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2NDF8MHwxfHNlYXJjaHwyfHxlbXB0eSUyMGZpZWxkfGVufDB8fHx8MTc1MzU0MDY2Mnww&ixlib=rb-4.1.0&q=85",
    "https://images.unsplash.com/photo-1670779431437-9723ebfcaaec?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1ODF8MHwxfHNlYXJjaHwxfHxteXN0aWNhbCUyMGRvb3J8ZW58MHx8fHwxNzUzNTQwNjcwfDA&ixlib=rb-4.1.0&q=85",
    "https://images.unsplash.com/photo-1623435830060-95d06be46de4?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1ODF8MHwxfHNlYXJjaHwzfHxteXN0aWNhbCUyMGRvb3J8ZW58MHx8fHwxNzUzNTQwNjcwfDA&ixlib=rb-4.1.0&q=85"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 3000);

    return () => clearInterval(interval);
  }, [images.length]);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/search?q=${encodeURIComponent(searchQuery.trim())}`;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black text-white">
      {/* Navigation */}
      <nav className="p-6">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1 className="chrome-font text-3xl font-bold">3rDspaces</h1>
          <div className="flex gap-4">
            <Link 
              to="/content" 
              className="bg-white text-black px-6 py-2 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Browse Content
            </Link>
            <Link 
              to="/search" 
              className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors"
            >
              Search Dublin
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h2 className="text-5xl font-bold mb-6">
            Welcome to <span className="chrome-font">3rDspaces</span>
          </h2>
          <p className="text-xl text-gray-300 mb-4">
            Dublin's Cultural Discovery Platform
          </p>
          <p className="text-lg text-gray-400 mb-8">
            📍 Dublin, Ireland • Find events, arts, food & culture with price-aware filtering
          </p>
        </div>

        {/* Google-style Search Bar */}
        <div className="max-w-2xl mx-auto mb-12">
          <form onSubmit={handleSearch} className="relative">
            <div className="flex items-center bg-white rounded-full shadow-lg">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Dublin's cultural scene..."
                className="flex-1 px-6 py-4 text-lg text-gray-800 bg-transparent rounded-full outline-none"
              />
              <button
                type="submit"
                className="mr-2 p-3 text-gray-600 hover:text-gray-800 transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </button>
            </div>
          </form>
        </div>

        {/* Moving Field Rectangle */}
        <div className="flex justify-center mb-12">
          <div className="relative w-96 h-64 rounded-lg overflow-hidden shadow-2xl">
            <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-blue-500 opacity-20"></div>
            <img
              src={images[currentImageIndex]}
              alt="Door to everchanging worlds"
              className="w-full h-full object-cover transition-all duration-1000 ease-in-out"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="bg-black bg-opacity-50 px-4 py-2 rounded-lg">
                <p className="text-white text-sm font-medium">Door to Dublin's Cultural Worlds</p>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <Link 
            to="/search"
            className="inline-block bg-gradient-to-r from-black to-gray-800 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:from-gray-800 hover:to-black transition-all transform hover:scale-105 mr-4"
          >
            Search Dublin Culture
          </Link>
          <Link 
            to="/content"
            className="inline-block bg-gradient-to-r from-green-600 to-green-800 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:from-green-700 hover:to-green-900 transition-all transform hover:scale-105"
          >
            Browse All Content
          </Link>
        </div>
      </div>
    </div>
  );
};

// Search Component with Google-style interface
const SearchPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");

  useEffect(() => {
    // Get search query from URL params
    const urlParams = new URLSearchParams(window.location.search);
    const q = urlParams.get('q');
    if (q) {
      setSearchQuery(q);
      performSearch(q);
    }
    
    // Load categories
    loadCategories();
  }, []);

  const loadCategories = async () => {
    try {
      const response = await axios.get(`${API}/categories`);
      setCategories(response.data.categories);
    } catch (error) {
      console.error('Error loading categories:', error);
    }
  };

  const performSearch = async (query = searchQuery, category = selectedCategory, min = minPrice, max = maxPrice) => {
    if (!query.trim() && !category) return;
    
    setLoading(true);
    try {
      const searchData = {
        query: query.trim(),
        category: category || null,
        min_price: min ? parseFloat(min) : null,
        max_price: max ? parseFloat(max) : null
      };

      const response = await axios.post(`${API}/search`, searchData);
      setSearchResults(response.data.results || []);
    } catch (error) {
      console.error('Search error:', error);
      setSearchResults([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    performSearch();
  };

  const handleFilterChange = () => {
    performSearch(searchQuery, selectedCategory, minPrice, maxPrice);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="chrome-font text-2xl font-bold text-gray-800">
              3rDspaces
            </Link>
            <div className="flex items-center text-sm text-gray-600">
              📍 Dublin, Ireland
            </div>
          </div>
          
          {/* Search Bar */}
          <div className="mt-4">
            <form onSubmit={handleSearch} className="flex items-center max-w-3xl">
              <div className="flex-1 flex items-center bg-white border rounded-full shadow-sm hover:shadow-md transition-shadow">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search Dublin's cultural scene..."
                  className="flex-1 px-6 py-3 text-gray-800 bg-transparent outline-none"
                />
                <button
                  type="submit"
                  className="mr-2 p-2 text-gray-600 hover:text-gray-800 transition-colors"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </button>
              </div>
            </form>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Filters Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            
            {/* Category Filter */}
            <div className="bg-white p-4 rounded-lg shadow">
              <h3 className="font-semibold mb-3">Category</h3>
              <select
                value={selectedCategory}
                onChange={(e) => {
                  setSelectedCategory(e.target.value);
                  setTimeout(handleFilterChange, 100);
                }}
                className="w-full p-2 border rounded-md"
              >
                <option value="">All Categories</option>
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>
            </div>

            {/* Price Filter */}
            <div className="bg-white p-4 rounded-lg shadow">
              <h3 className="font-semibold mb-3">Price Range (€)</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm text-gray-600 mb-1">Min Price</label>
                  <input
                    type="number"
                    value={minPrice}
                    onChange={(e) => setMinPrice(e.target.value)}
                    onBlur={handleFilterChange}
                    placeholder="0"
                    className="w-full p-2 border rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-600 mb-1">Max Price</label>
                  <input
                    type="number"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(e.target.value)}
                    onBlur={handleFilterChange}
                    placeholder="No limit"
                    className="w-full p-2 border rounded-md"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Search Results */}
          <div className="lg:col-span-3">
            
            {/* Results Summary */}
            <div className="mb-6">
              <p className="text-gray-600">
                {searchQuery && (
                  <>About {searchResults.length} results for "<strong>{searchQuery}</strong>"</>
                )}
                {!searchQuery && searchResults.length > 0 && (
                  <>Showing {searchResults.length} results</>
                )}
              </p>
            </div>

            {/* Loading State */}
            {loading && (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="bg-white p-4 rounded-lg shadow animate-pulse">
                    <div className="h-6 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                  </div>
                ))}
              </div>
            )}

            {/* Search Results */}
            {!loading && searchResults.length > 0 && (
              <div className="space-y-4">
                {searchResults.map((result, index) => (
                  <div key={result.id || index} className="bg-white p-6 rounded-lg shadow hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="text-xl text-blue-600 hover:text-blue-800 cursor-pointer font-medium">
                        {result.source_url ? (
                          <a href={result.source_url} target="_blank" rel="noopener noreferrer">
                            {result.title}
                          </a>
                        ) : (
                          result.title
                        )}
                      </h3>
                      <span className="text-sm bg-gray-100 text-gray-700 px-2 py-1 rounded-full">
                        {result.category}
                      </span>
                    </div>
                    
                    {result.source_url && (
                      <p className="text-green-700 text-sm mb-2">{result.source_url}</p>
                    )}
                    
                    <p className="text-gray-700 mb-3 leading-relaxed">
                      {result.text.length > 200 
                        ? `${result.text.substring(0, 200)}...` 
                        : result.text
                      }
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        {result.price_mentions && result.price_mentions.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {result.price_mentions.map((price, idx) => (
                              <span
                                key={idx}
                                className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium"
                              >
                                €{price}
                              </span>
                            ))}
                          </div>
                        )}
                        {result.source_site && (
                          <span className="text-gray-500 text-sm">
                            Source: {result.source_site}
                          </span>
                        )}
                      </div>
                      
                      <span className="text-gray-400 text-sm">
                        {result.location || 'Dublin, Ireland'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* No Results */}
            {!loading && searchResults.length === 0 && searchQuery && (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg mb-4">No results found for "{searchQuery}"</p>
                <p className="text-gray-400">Try different keywords or adjust your filters</p>
              </div>
            )}

            {/* Initial State */}
            {!loading && searchResults.length === 0 && !searchQuery && (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg">Enter a search term to explore Dublin's cultural scene</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Price Range Slider Component (Enhanced)
const PriceRangeSlider = ({ minPrice, maxPrice, onPriceChange }) => {
  const [localMin, setLocalMin] = useState(minPrice || 0);
  const [localMax, setLocalMax] = useState(maxPrice || 200);

  const handleMinChange = (e) => {
    const value = parseInt(e.target.value);
    setLocalMin(value);
    onPriceChange(value, localMax);
  };

  const handleMaxChange = (e) => {
    const value = parseInt(e.target.value);
    setLocalMax(value);
    onPriceChange(localMin, value);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg mb-6">
      <h3 className="text-lg font-semibold mb-4 text-gray-800">Filter by Price Range (€)</h3>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Min Price: €{localMin}
          </label>
          <input
            type="range"
            min="0"
            max="200"
            value={localMin}
            onChange={handleMinChange}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Max Price: €{localMax}
          </label>
          <input
            type="range"
            min="0"
            max="200"
            value={localMax}
            onChange={handleMaxChange}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
          />
        </div>
        <div className="flex justify-between text-sm text-gray-600">
          <span>€0</span>
          <span>€200+</span>
        </div>
      </div>
    </div>
  );
};

// Content Card Component (Enhanced)
const ContentCard = ({ content }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
      <div className="flex items-start justify-between mb-2">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{content.title}</h3>
        <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
          {content.category}
        </span>
      </div>
      
      <p className="text-gray-600 mb-4">{content.text}</p>
      
      <div className="flex flex-wrap gap-2 mb-3">
        {content.price_mentions.map((price, index) => (
          <span
            key={index}
            className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium"
          >
            €{price}
          </span>
        ))}
      </div>
      
      <div className="flex items-center justify-between text-sm text-gray-500">
        <div>
          {content.source_site && (
            <span className="mr-4">📍 {content.source_site}</span>
          )}
          <span>{content.location || 'Dublin, Ireland'}</span>
        </div>
        <span>
          {new Date(content.timestamp).toLocaleDateString()}
        </span>
      </div>
      
      {content.source_url && (
        <div className="mt-3">
          <a
            href={content.source_url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-600 hover:text-blue-800 text-sm"
          >
            View Original →
          </a>
        </div>
      )}
    </div>
  );
};

// Content Listing Page (Enhanced)
const ContentPage = () => {
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [minPrice, setMinPrice] = useState(null);
  const [maxPrice, setMaxPrice] = useState(null);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");

  const fetchContent = async (min = null, max = null, category = null) => {
    try {
      setLoading(true);
      let url = `${API}/content`;
      const params = new URLSearchParams();
      
      if (min !== null) params.append('min_price', min);
      if (max !== null) params.append('max_price', max);
      if (category) params.append('category', category);
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }

      const response = await axios.get(url);
      setContent(response.data);
    } catch (error) {
      console.error('Error fetching content:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadCategories = async () => {
    try {
      const response = await axios.get(`${API}/categories`);
      setCategories(response.data.categories);
    } catch (error) {
      console.error('Error loading categories:', error);
    }
  };

  useEffect(() => {
    fetchContent();
    loadCategories();
  }, []);

  const handlePriceChange = (min, max) => {
    setMinPrice(min);
    setMaxPrice(max);
    fetchContent(min, max, selectedCategory);
  };

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    fetchContent(minPrice, maxPrice, category);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm p-6">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <Link to="/" className="chrome-font text-2xl font-bold text-gray-800">
            3rDspaces
          </Link>
          <div className="flex items-center gap-4">
            <Link 
              to="/search" 
              className="text-green-600 hover:text-green-800 transition-colors"
            >
              🔍 Search Dublin
            </Link>
            <Link 
              to="/" 
              className="text-gray-600 hover:text-gray-800 transition-colors"
            >
              ← Back to Home
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Sidebar with Filters */}
          <div className="lg:col-span-1 space-y-6">
            <PriceRangeSlider
              minPrice={minPrice}
              maxPrice={maxPrice}
              onPriceChange={handlePriceChange}
            />
            
            {/* Category Filter */}
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold mb-4 text-gray-800">Category</h3>
              <div className="space-y-2">
                <button
                  onClick={() => handleCategoryChange("")}
                  className={`w-full text-left p-2 rounded transition-colors ${
                    selectedCategory === "" ? "bg-blue-100 text-blue-800" : "hover:bg-gray-100"
                  }`}
                >
                  All Categories
                </button>
                {categories.map(category => (
                  <button
                    key={category}
                    onClick={() => handleCategoryChange(category)}
                    className={`w-full text-left p-2 rounded transition-colors ${
                      selectedCategory === category ? "bg-blue-100 text-blue-800" : "hover:bg-gray-100"
                    }`}
                  >
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Content Grid */}
          <div className="lg:col-span-3">
            <div className="mb-6">
              <h2 className="text-3xl font-bold text-gray-800 mb-2">Dublin Cultural Feed</h2>
              <p className="text-gray-600">
                📍 Dublin, Ireland • {content.length} items found
                {(minPrice !== null || maxPrice !== null) && 
                  ` (filtered by price: €${minPrice || 0} - €${maxPrice || '200+'})`
                }
                {selectedCategory && ` in ${selectedCategory}`}
              </p>
            </div>

            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-lg p-6 animate-pulse">
                    <div className="h-6 bg-gray-200 rounded mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded mb-4"></div>
                    <div className="flex gap-2">
                      <div className="h-6 w-16 bg-gray-200 rounded-full"></div>
                      <div className="h-6 w-16 bg-gray-200 rounded-full"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {content.map((item) => (
                  <ContentCard key={item.id} content={item} />
                ))}
              </div>
            )}

            {!loading && content.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg">
                  No content found matching your filters.
                </p>
                <p className="text-gray-400 mt-2">
                  Try adjusting your price range or category selection.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Main App Component
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/content" element={<ContentPage />} />
          <Route path="/search" element={<SearchPage />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;